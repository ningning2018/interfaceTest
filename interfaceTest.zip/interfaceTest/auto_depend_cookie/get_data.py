#coding:utf-8
from interfaceAuto.auto_depend_cookie.operation_excel import Operation_Excel
from interfaceAuto.auto_depend_cookie.operation_json import OperationJson
# from data_config import dataConfig
from interfaceAuto.auto_depend_cookie.data_config import dataConfig

class GetData:
    def __init__(self):
        self.ope_excel = Operation_Excel()
        self.ope_json = OperationJson()
        self.data = dataConfig()
    def get_lines(self):
        nrows = self.ope_excel.get_lines()
        return nrows
    def get_is_run(self,row):
        col = int(dataConfig.run())
        is_run = self.ope_excel.get_value(row,col)
        if is_run == 'yes':
            return True
        else:
            return False
    def get_request_url(self,row):
        col = int(dataConfig.url())
        url = self.ope_excel.get_value(row,col)
        if url == None:
            return None
        else:
            return url
    def get_request_method(self,row):
        col = int(dataConfig.method())
        method = self.ope_excel.get_value(row,col)
        if method != None:
            return method
        else:
            return None
    def get_is_header(self,row):
        col = int(dataConfig.header())
        header = self.ope_excel.get_value(row,col)
        if header =='yes':
            return header
        else:
            return None
    def get_request_data(self,row):
        col = int(dataConfig.data())
        data = self.ope_excel.get_value(row,col)
        if data == None:
            return None
        else:
            return data
    def get_data_for_json(self,row):
        data = self.get_request_data(row)
        request_data = self.ope_json.get_data(data)
        return request_data
    def get_expect_data(self,row):
        col = int(dataConfig.yuqi())
        expect = self.ope_excel.get_value(row,col)
        if expect =='':
            return None
        else:
            return expect
    def write_result_value(self,row,value):
        col = int(dataConfig.result())
        self.ope_excel.write_value(row,col,value)
    def get_depend_key(self,row):
        col = int(dataConfig.depend_data_id())
        key = self.ope_excel.get_value(row,col)
        if key == '':
            return None
        else:
            return key
    def is_denpend(self,row):
        col = int(dataConfig.depend_case_id())
        case = self.ope_excel.get_value(row,col)
        if case == '':
            return None
        else:
            return case
    def get_depend_field(self,row):
        col = int(dataConfig.depend_field_id())
        field = self.ope_excel.get_value(row,col)
        if field == '':
            return None
        else:
            return field
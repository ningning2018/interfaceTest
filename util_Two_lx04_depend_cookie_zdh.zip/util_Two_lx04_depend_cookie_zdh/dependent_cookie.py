#coding:utf-8
import json
from operation_json import OperationJson
import requests
#cookies 存取   dependent_cookie+runmethod中的header改成cookies+get_data中的get_header_value() 改成header + run_test中的if..elif..
class Depend_Cookie:
    def __init__(self,response):
        self.response = json.loads(response)
    def get_response_url(self):
        url = self.response['data']['url'][0]
        return url
    def get_cookies(self):
        url = self.get_response_url()+'&callback=jQuery19109209415014008073_1519811299116&_=1519811299119'
        cookie = requests.get(url).cookies
        return cookie
    def write_cookies(self):
        cookie = requests.utils.dict_from_cookiejar(self.get_cookies())
        op_json = OperationJson()
        op_json.write_value(cookie)

# if __name__=='__main__':
#     url = "https://www.imooc.com/passport/user/login"
#     data = {
#         "username":"234709493@qq.com",
#         "password":"zgn123ningf",
#         "verify":"",
#         "referer":"https://m.imooc.com"
#     }
#     data = json.dumps(requests.post(url,data,verify=False).json())
#     cookie = Depend_Cookie(data)
#     # cookie.get_cookies()
#     cookie.write_cookies()
#     coo = cookie.get_cookies()
#     cee = requests.utils.dict_from_cookiejar(coo)
#     print cee['apsid']

if __name__=='__main__':
    url = "https://www.imooc.com/passport/user/login"
    data = {
        "username":"234709493@qq.com",
        "password":"zgn123ningf",
        "verify":"",
        "referer":"https://m.imooc.com"
    }
    url1 = 'https://passport.isoftstone.com/?DomainUrl=http://ipsapro.isoftstone.com&ReturnUrl=%2fPortal'
    data1 = {
        'emp_DomainName':'gnzhong',
        'emp_Password':'abcdef.1234',
        'RemeberMe':'true',
        'DomainUrl':'',
        'ReturnUrl':''
    }
    data = json.dumps(requests.post(url1,data1,verify=False).json())
    cookie = Depend_Cookie(data)
    # cookie.get_cookies()
    # cookie.write_cookies()
    # coo = cookie.get_cookies()
    # cee = requests.utils.dict_from_cookiejar(coo)
    # print cee['apsid']


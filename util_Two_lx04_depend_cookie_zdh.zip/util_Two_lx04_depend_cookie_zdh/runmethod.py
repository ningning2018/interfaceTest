#coding:utf-8
#新增put、delete请求
import requests
import json
class RunMethod:
    def send_post(self,url,data=None,cookies=None):
        res = None
        if cookies != None:
            res = requests.post(url=url,data=data,cookies=cookies,verify=False)
        else:
            res = requests.post(url=url,data=data,verify=False)
        return res.json()
    def send_get(self,url,data=None,cookies=None):
        res = None
        if cookies != None:
            res = requests.get(url=url,data=data,cookies=cookies,verify=False)
        else:
            res = requests.get(url=url,data=data,verify=False)
        return res.json()
    def send_put(self,url,data=None,cookies=None):
        res = None
        if cookies != None:
            res = requests.put(url=url,data=data,cookies=cookies,verify=False)
        else:
            res = requests.put(url=url,data=data,verify=False)
        return res.json()
    def send_delete(self,url,data=None,cookies=None):
        res = None
        if cookies != None:
            res = requests.delete(url=url,data=data,cookies=cookies,verify=False)
        else:
            res = requests.delete(url=url,data=data,verify=False)
        return res.json()

    def send_main(self,method,url,data=None,cookies=None):
        res = None
        if method =='post':
            res = self.send_post(url,data,cookies)
        elif method == 'get':
            res = self.send_get(url,data,cookies)
        elif method == 'put':
            res = self.send_put(url,data,cookies)
        elif method == 'delete':
            res = self.send_delete(url,data,cookies)
        # return json.dumps(res,ensure_ascii=False,sort_keys=True,indent=2)
        return json.dumps(res,ensure_ascii=False)      #加上数据库操作时，换成这个
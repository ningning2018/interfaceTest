#coding:utf-8
class dataConfig:
    id = '0'
    mc_name = '1'
    url = '2'
    run = '3'
    method = '4'
    header = '5'
    depend_case_id = '6'
    depend_data_id = '7'
    depend_field_id = '8'
    data = '9'
    yuqi  = '10'
    result = '11'
def get_id():
    return dataConfig.id
def get_mc_name():
    return dataConfig.mc_name
def get_url():
    return dataConfig.url
def get_run():
    return dataConfig.run
def get_method():
    return dataConfig.method
def get_header():
    return dataConfig.header
def get_depend_case_id():
    return dataConfig.depend_case_id
def get_depend_data_id():
    return dataConfig.depend_data_id
def get_depend_field_id():
    return dataConfig.depend_field_id
def get_data():
    return dataConfig.data
def get_yuqi():
    return dataConfig.yuqi
def get_result():
    return dataConfig.result
def get_header_value():
    header ={
        # 'apsid':"fjdskalfdjalkjjfdklas&fdjsl=fdjskla"
    }
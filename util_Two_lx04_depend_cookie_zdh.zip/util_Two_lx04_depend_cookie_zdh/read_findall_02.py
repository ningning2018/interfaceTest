#coding:utf-8
import re
import os
import json
class readAndGetData:
    def __init__(self,fila=None):
        if fila==None:
            self.fila = 'mynewproject'
        else:
            self.fila = fila
    def read_findall(self):
        bb = []
        dd = []
        file4 = os.walk(self.fila)
        for i in file4:
            bb.append(i)
        cc = len(bb)
        for z in range(cc):
            if bb[z][2]:
                if len(bb[z][2])<=1:
                    count = bb[z][0]+'\\'+str(bb[z][2][0])
                    dd.append(count)
                else:
                    for s in range(len(bb[z][2])):
                        count = bb[z][0]+'\\'+str(bb[z][2][s])
                        dd.append(count)
        return dd
    def get_excel_data(self):
        ef = len(self.read_findall())
        for af in range(ef):
            fg5 = self.read_findall()[af]
            ffg5 = open(fg5,'r')
            line5 = ffg5.read()
            if 'views.py' in fg5 and 'views.pyc' not in fg5:
                listsum = line5.split('def ')
                num = len(listsum)
                cco = []
                for i in range(num-1):
                    j = i + 1
                    aa = re.findall("(.*?)\(request\)",listsum[j])
                    bb = re.findall("request.method\s*==\s*\'(.*?)\':",listsum[j])
                    cc = re.findall("content_type\s*=\'(.*?)\'",listsum[j])
                    dd = re.findall("render_to_response\(\'(.*?)\'\)",listsum[j])
                    ee = re.findall("\[\'(.*?)\'\]",listsum[j])
                    # print aa,bb,cc,dd,ee
                    ff = aa+bb+cc+dd+ee
                    # print ff
                    cco.append(ff)
                return cco
    def get_url_excel(self):
        ef = len(self.read_findall())
        for af in range(ef):
            fg = self.read_findall()[af]
            ffg = open(fg,'r')
            lines = ffg.read()
            urlandlist = []
            urltrue = []
            if 'urls.py' in fg and 'urls.pyc' not in fg:
                urllist = re.findall("url\(r\'\^(.*?)\',\s*(.*?)\)\,",lines)
                urlandlist.append(urllist)
                for g in urlandlist[0][2:]:
                    urltrue.append(g)
                return urltrue
    def get_file_settings(self):
        ef = len(self.read_findall())
        for af in range(ef):
            fg = self.read_findall()[af]
            ffg = open(fg,'r')
            lines = ffg.read()
            if 'settings.py' in fg and 'settings.pyc'not in fg:
                # setting_list = re.findall("INSTALLED_APPS\s*=\s*\[.*(\s|\S){1,}(.*?)(\s|\S){1,}.*MIDDLEWARE\s*=\s*\[",lines)
                setting_list = lines.split('INSTALLED_APPS')[1].split('MIDDLEWARE = [')[0].split("'")
                setlen = len(setting_list)
                setting_count = []
                last_setting = []
                for i in range(setlen/2):
                    j = i*2+1
                    setting_count.append(setting_list[j])
                len_setting = len(setting_count)
                for h in range(len_setting-6):
                    k = h+6
                    last_setting.append(setting_count[k])
                return last_setting

if __name__ == '__main__':
    read = readAndGetData()
    print len(read.read_findall())
    print read.get_excel_data()
    print read.get_url_excel()
    print read.get_file_settings()
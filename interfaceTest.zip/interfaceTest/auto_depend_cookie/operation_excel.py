#coding:utf-8
import xlrd
from xlutils.copy import copy
class Operation_Excel:
    # data = xlrd.open_workbook('../utilTwo_data_lx01/myOne.xlsx')
    # tables = data.sheets()[0]
    # print tables.nrows
    # print tables.cell_value(1,2)
    def __init__(self,excel_name=None,sheet_id=None):
        if excel_name:
            self.excel_name = excel_name
            self.sheet_id = sheet_id
        else:
            self.excel_name = '../interfaceTest/utilTwo_data_lx01/writeOne.xlsx'
            self.sheet_id = 0
        self.data = self.read_data()
    def read_data(self):
        data = xlrd.open_workbook(self.excel_name)
        tables = data.sheets()[0]
        return tables
    def get_lines(self):
        return self.data.nrows
    def get_value(self,row,col):
        return self.data.cell_value(row,col)
    def write_value(self,row,col,value):
        get_value1 = xlrd.open_workbook(self.excel_name)
        copy_value1 = copy(get_value1)
        write_sheet1 = copy_value1.get_sheet(0)
        write_sheet1.write(row,col,value)
        copy_value1.save(self.excel_name)

    def get_cols_data(self,col_id=None):
        if col_id != None:
            cols = self.data.col_values(col_id)
        else:
            cols = self.data.col_values(0)
        return cols
    def get_row_num(self,case_id):
        num = 0
        cols_data = self.get_cols_data()
        for col_data in cols_data:
            if case_id in col_data:
                return num
            num = num + 1
    def get_row_values(self,row):
        sheet_value = self.data
        row_data = sheet_value.row_values(row)
        return row_data
    def get_rows_data(self,case_id):
        row_num = self.get_row_num(case_id)
        row_data = self.get_row_values(row_num)
        return row_data

if __name__=='__main__':
    oop = Operation_Excel()
    # print oop.excel_name
    # print oop.sheet_id
    # print oop.get_value(3,2)
    # print oop.get_lines()
    # print oop.get_cols_data(0)
    # print oop.get_row_num('my02')
    # print oop.get_row_values(2)
    # print oop.get_rows_data('my03')
    # print oop.write_value(3,2,'http://127.0.0.1:8000/loginssa/')
    # print oop.get_value(5,10)
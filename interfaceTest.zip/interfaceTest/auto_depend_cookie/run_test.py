#coding:utf-8
#add cookies
from interfaceAuto.auto_depend_cookie.commit_util import Commit
from interfaceAuto.auto_depend_cookie.dependent_cookie import Depend_Cookie
from interfaceAuto.auto_depend_cookie.operation_json import OperationJson
from interfaceAuto.auto_depend_cookie.operation_excel import Operation_Excel
from interfaceAuto.auto_depend_cookie.runmethod import RunMethod
from interfaceAuto.auto_depend_cookie.send_email import SendEmail
from interfaceAuto.auto_depend_cookie.get_data import GetData
from interfaceAuto.auto_depend_cookie.dependent_data import DependentData
import json
from interfaceAuto.auto_depend_cookie.write_excel_json import write_to_data
class RunTest:
    def __init__(self):
        self.comUtil = Commit()
        self.data = GetData()
        self.runMeth = RunMethod()
        self.sen_mai = SendEmail()
        self.wrdata = write_to_data()
    def writedata(self):
        self.wrdata.write_id_0()
        self.wrdata.write_name_1()
        self.wrdata.write_url_2()
        self.wrdata.write_run_3()
        self.wrdata.write_method_4()
        self.wrdata.write_is_cookie_5()
        self.wrdata.write_data_main_6()
        self.wrdata.write_data_yuqi_10()
        self.wrdata.write_data_to_json_01()
    def go_on(self):
        res = None
        pass_count = []
        fail_count = []
        nrow = self.data.get_lines()
        for i in range(1,nrow):
            is_run = self.data.get_is_run(i)
            if is_run:
                url = self.data.get_request_url(i)
                method = self.data.get_request_method(i)
                request_data = self.data.get_data_for_json(i)
                expect = self.data.get_expect_data(i)
                header = self.data.get_is_header(i)
                depend_case = self.data.is_denpend(i)
                if depend_case != None:
                    self.depend_data = DependentData(depend_case)
                    depend_request_data = self.depend_data.get_data_for_key(i)
                    depend_key = self.data.get_depend_field(i)
                    request_data[depend_key] = depend_request_data
                if header == 'write':
                    res = self.runMeth.send_main(method,url,request_data)
                    op_cookie = Depend_Cookie(res)
                    op_cookie.write_cookies()
                elif header == 'yes':
                    op_json = OperationJson('../dataconfigOne/cookie.json')
                    cookie = op_json.get_data('apsid')
                    cookies = {
                        'apsid':cookie
                    }
                    res = self.runMeth.send_main(method,url,request_data,cookies)
                else:
                    res = self.runMeth.send_main(method,url,request_data)
                print(res)
                if self.comUtil.is_equal_dict(expect,res) == 0:
                    self.data.write_result_value(i,'pass')
                    pass_count.append(i)
                else:
                    self.data.write_result_value(i,res)
                    fail_count.append(i)
            # print res
        self.sen_mai.send_main(pass_count,fail_count,res)
if __name__=='__main__':
    run = RunTest()
    run.writedata()
    run.go_on()

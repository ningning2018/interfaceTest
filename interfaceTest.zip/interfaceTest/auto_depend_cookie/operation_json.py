#coding:utf-8
import json
class OperationJson:
    def __init__(self,file_path=None):
        if file_path:
            self.file_path = file_path
        else:
            self.file_path = 'last_dict_01.json'
        self.data = self.read_data()
    def read_data(self):
        with open(self.file_path) as fp:
            data = json.load(fp)
            return data
    def get_data(self,id):
        return self.data[id]
    def write_value(self,data):
        with open('last_dict_01.json','w') as fp:
            fp.write(json.dumps(data))
    # def write_json_data(self,data):
    #     with open('last_dict_01.json','w') as fp:
    #         fp.write(json.dumps(data))
if __name__=='__main__':
    aaa = OperationJson()


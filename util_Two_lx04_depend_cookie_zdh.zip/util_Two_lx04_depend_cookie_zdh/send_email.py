#coding:utf-8
import smtplib
from email.mime.text import MIMEText
import json
class SendEmail:
    global smtp_host
    global use_email
    global password
    smtp_host = 'smtp.qq.com'
    use_email = '234709493@qq.com'
    password = 'drsxxbfshpfzcaij'
    def sen_mail(self,user_list,sub,content):
        user = '钟先生'+'<'+use_email+'>'
        manage = MIMEText(content,_subtype='plain',_charset='utf-8')
        manage['Subject'] = sub
        manage['From'] = user
        manage['To'] = ';'.join(user_list)
        server = smtplib.SMTP_SSL(smtp_host,465)
        server.helo(smtp_host)
        server.ehlo(smtp_host)
        server.login(use_email,password)
        server.sendmail(user,user_list,manage.as_string())
        server.quit()
    def send_main(self,pass_list,fail_list,res):
        pass_num = float(len(pass_list))
        fail_num = float(len(fail_list))
        count_num = pass_num+fail_num
        pass_result = '%.2f%%' %(pass_num/count_num*100)
        fail_result = '%.2f%%' %(fail_num/count_num*100)
        user_list = ['1147721103@qq.com']
        sub = '这是我第一次自己编写的接口自动化框架'
        content = '此次一共运行接口个数为%s个，执行成功个数为%s个，失败个数为%s个，成功率为%s,失败率为%s' %(count_num,pass_num,fail_num,pass_result,fail_result)+\
                  '。其中失败接口的请求参数是'+json.dumps(res)
        self.sen_mail(user_list,sub,content)
if __name__=='__main__':
    send = SendEmail()
    send.send_main([1,2,3,4,5,6,7,8,9],[1,2],'fffss')
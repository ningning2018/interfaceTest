#coding:utf-8
from interfaceAuto.auto_depend_cookie.operation_excel import Operation_Excel
from interfaceAuto.auto_depend_cookie.get_data import GetData
from interfaceAuto.auto_depend_cookie.runmethod import RunMethod
from jsonpath_rw import jsonpath,parse
import json
class DependentData:
    def __init__(self,case_id):
        self.case_id = case_id
        self.op_excel = Operation_Excel()
        self.data = GetData()
    def get_case_line_data(self):
        case = self.op_excel.get_rows_data(self.case_id)
        return case
    def run_dependent(self):
        run_method = RunMethod()
        row_num = self.op_excel.get_row_num(self.case_id)
        method = self.data.get_request_method(row_num)
        url = self.data.get_request_url(row_num)
        request_data = self.data.get_request_data(row_num)
        header = self.data.get_is_header(row_num)
        res = run_method.send_main(method,url,request_data,header)
        return json.loads(res)
    def get_data_for_key(self,row):
        depend_key = self.data.get_depend_key(row)
        response_data = self.run_dependent()
        json_exe = parse(depend_key)
        madle = json_exe.find(response_data)
        return [math.value for math in madle][0]

if __name__=='__main__':
    dep = DependentData(2)
    # dep.get_data_for_key(2)
    # dep.run_dependent()
    datas = {
        'data':{
            'out_trade_no': '12345567'
        }
    }
    res = 'data.out_trade_no'
    json_exe = parse(res)
    madle = json_exe.find(datas)
    print([math.value for math in madle][0])
    datass = {
        'login':{
            'login':'fff',
            'name':{
                'out_trade_no': '123',
                'name':'0000',
                'isname':{
                    'out_trade_no':'3456789',
                    'name':'111',
                    'ccc':{
                        'a1':22
                    }
                }
            }
        }
    }
    res = 'login.name.isname.ccc.a1'
    json_e = parse(res)
    madll = json_e.find(datass)
    print([maa.value for maa in madll][0])
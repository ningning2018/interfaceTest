from django.shortcuts import render
from django.http.response import HttpResponse
from django.shortcuts import render_to_response
import json

# Create your views here.
#def Logins(request):
#     if request.method == 'POST':
#         usernames = request.POST.get('usernames')
#         return HttpResponse(usernames)
#     else:
#         return render_to_response('logins.html')

def LoginsGet(request):
    if request.method == 'GET':
        result = {}
        usernamesrz = request.GET.get('usernamesr')
        passwordsrz=request.GET.get('passwordsr')
        datan = request.GET.get('dataw')
        result['user']=usernamesrz
        result['mobileNumum']=passwordsrz
        result['data']=datan
        result  = json.dumps(result)
        return HttpResponse(result,content_type='application/json;charset=utf-8')
    else:
        return render_to_response('logins.html')
#
def Logins(request):
    if request.method == 'POST':
        result = {}
        usernames = request.POST.get('usernames')
        # mobile=request.POST.get('passwords')
        passwords = request.POST.get('passwords')
        # result['user']=usernames
        # result['mobileNum']=mobile
        result['usernames'] = usernames
        result['passwords'] = passwords
        result  = json.dumps(result)
        return HttpResponse(result,content_type='application/json;charset=utf-8')
    else:
        return render_to_response('logins.html')

def Loginss(request):
    if request.method == 'POST':
        results ={}
        username = request.POST.get('usernamess')
        mobile = request.POST.get('passwordss')
        results['usernamess']=username
        results['passwordss']=mobile
        results = json.dumps(results)
        return HttpResponse(results,content_type='application/json;charset=utf-8')
    else:
        return render_to_response('loginss.html')

def Loginssa(request):
    if request.method == 'POST':
        resultssa = {}
        usernamessa = request.POST.get('usernamessa')
        passwordssa = request.POST.get('passwordssa')
        # emailssa = request.POST.get('emailssa')
        resultssa['usernamessa'] = usernamessa
        resultssa['passwordssa']  = passwordssa
        # resultssa['emailssa'] = emailssa
        resultssa = json.dumps(resultssa)
        return HttpResponse(resultssa,content_type='application/json;charset=utf-8')
    else:
        return render_to_response('loginssa.html')

def Exhibition(request):
    if request.method == 'POST':
        res = {}
        usernamessaa = request.POST.get('usernamessaa')
        passwordssaa = request.POST.get('passwordssaa')
        # orderNum = request.POST.get('orderNum')
        res['usernamessaa'] = usernamessaa
        res['passwordssaa'] = passwordssaa
        # res['orderNum'] = orderNum
        res = json.dumps(res)
        return HttpResponse(res,content_type='application/json;charset=utf-8')
    else:
        return render_to_response('register.html')

def GetData(request):
    if request.method == 'GET':
        Res = {}
        Getdata1 = request.GET.get('getdata1')
        Getdata2 = request.GET.get('getdata2')
        Res['data1'] = Getdata1
        Res['data2'] = Getdata2
        Res = json.dumps(Res)
        return HttpResponse(Res,content_type='application/json;charset=utf-8')
    else:
        return render_to_response('loginGet.html')
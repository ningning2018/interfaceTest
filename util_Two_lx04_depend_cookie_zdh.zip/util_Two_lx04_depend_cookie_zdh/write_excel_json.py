#coding:utf-8
from read_findall_02 import readAndGetData
from operation_excel import Operation_Excel
from operation_json import OperationJson
import data_config
import re
import os
import json
class write_to_data:
    def __init__(self):
    # def __init__(self,wr_excel=None,wr_json=None):
        # if wr_excel:
        #     self.wr_excel = wr_excel
        # else:
        #     self.wr_excel = '../utilTwo_data_lx01/writeOne.xlsx'
        # if wr_json:
        #     self.wr_json = wr_json
        # else:
        #     self.wr_json = '../utilTwo_data_lx01/writeOne.json'
        self.readFile = readAndGetData()
        self.op_excel = Operation_Excel('../utilTwo_data_lx01/writeOne.xlsx')
        self.op_json = OperationJson('../utilTwo_data_lx01/writeOne.json')
    def write_id_0(self):
        wrline = len(self.readFile.get_url_excel())
        print wrline
        for i in range(wrline):
            self.op_excel.write_value(i+1,int(data_config.get_id()),'ning'+str(i+1))
    def write_name_1(self):
        wrline = len(self.readFile.get_url_excel())
        for i in range(wrline):
            self.op_excel.write_value(i+1,int(data_config.get_mc_name()),self.readFile.get_url_excel()[i])
    def url_list1(self):
        urlintf = self.readFile.get_url_excel()
        str_urlintf = [str(i) for i in urlintf]
        join_urlintf = ''.join(str_urlintf)
        split_join = re.split("'",join_urlintf)
        len_join = len(split_join)
        url_list = []
        for i in range(len_join/4):
            j = i*4+1
            url_list.append(split_join[j])
        return url_list
    def write_url_2(self):
        wrline = len(self.readFile.get_url_excel())
        for i in range(wrline):
            self.op_excel.write_value(i+1,int(data_config.get_url()),'http://127.0.0.1:8000/'+self.url_list1()[i])
    def write_run_3(self):
        wrline = len(self.readFile.get_url_excel())
        for i in range(wrline):
            self.op_excel.write_value(i+1,int(data_config.get_run()),'yes')
    def method_list(self):
        data_count = self.readFile.get_excel_data()
        len_data = len(data_count)
        method_count = []
        for i in range(1,len_data):
            data_list = data_count[i][1]
            method_count.append(data_list)
        return method_count
    def write_method_4(self):
        wrline = len(self.readFile.get_url_excel())
        for i in range(wrline):
            self.op_excel.write_value(i+1,int(data_config.get_method()),self.method_list()[i])
    def write_is_cookie_5(self):
        wrline = len(self.readFile.get_url_excel())
        for i in range(wrline):
            self.op_excel.write_value(i+1,int(data_config.get_header()),'no')
    def data_main_list(self):
        urlintf = self.readFile.get_url_excel()
        str_urlintf = [str(i) for i in urlintf]
        join_urlintf = ''.join(str_urlintf)
        split_join = re.split("'",join_urlintf)
        len_join = len(split_join)
        url_list = []
        for i in range(len_join/4):
            j = i*4+3
            url_list.append(split_join[j])
        return url_list
    def write_data_main_6(self):
        wrline = len(self.readFile.get_url_excel())
        for i in range(wrline):
            self.op_excel.write_value(i+1,int(data_config.get_data()),self.data_main_list()[i])
    def data_list_yuqi(self):
        urlintf = self.readFile.get_excel_data()
        len_urlintf = len(urlintf)
        data_list = []
        for i in range(1,len_urlintf):
            data = urlintf[i][4:]
            data_list.append(data)
        return data_list
    def json_1(self,list):
        obj = {}
        for i in range(len(list)):
            obj[list[i]]=i
        return obj
    def json_json_2(self,list1,list2):
        obj = {}
        for i in range(len(list1)):
            obj[list1[i]]=self.json_1(list2[i])
        return obj
    def json_in_json(self):
        aa = self.json_json_2(self.data_main_list(),self.data_list_yuqi())
        return aa
    def write_data_to_json_01(self):
        self.op_json.write_json_data(self.json_in_json())
    def json_to_yuqi(self):
        gg = len(self.data_list_yuqi())
        oo = []
        for i in range(gg):
            cc = self.json_1(self.data_list_yuqi()[i])
            oo.append(cc)
        return oo
    def write_data_yuqi_10(self):
        urlintf = len(self.readFile.get_excel_data())
        for i in range(urlintf-1):
            self.op_excel.write_value(i+1,int(data_config.get_yuqi()),str(self.json_to_yuqi()[i]))
if __name__ == '__main__':
    run = write_to_data()
    # run.write_id_0()
    # run.write_name_1()
    # run.write_url_2()
    run.write_run_3()
    # run.write_method_4()
    # run.write_is_cookie_5()
    # run.write_data_main_6()
    # run.write_data_yuqi_10()
    # run.write_data_to_json_01()

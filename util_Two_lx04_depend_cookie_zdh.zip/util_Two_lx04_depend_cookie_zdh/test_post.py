#coding:utf-8
#这是成功的单独接口发送  包含cookies
import requests
import json
cookies = {
    "apsid":"E1NDcwMjg1MTdiN2NkMmI2Y2ZmOTgyYTZlZDRiMjUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMzY5OTE3OAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAyMzQ3MDk0OTNAcXEuY29tAAAAAAAAAAAAAAAAAAAAADBlYTE4MWQ3MzA0N2E2MzQzNDY0MWQ5ZjlhY2VhODE0MMV%2BWjDFflo%3DMz"
}
# list_data = json.dumps([{"goods_id":"346","type":"1","type_id":"131","status":"1","price":"388.00","ios_price":"388.00","service_lifetime":0,"open_discount":"0","discount_start_time":"1503936000","discount_end_time":"1503936000","discount_price":"0.00","discount_type":"0","code_white_list":10001,"using_discount":False,"pay_price":"388.00","code":0},
#     {"goods_id":"362","type":"1","type_id":"136","status":"1","price":"366.00","ios_price":"366.00","service_lifetime":90,"open_discount":"0","discount_start_time":"1505232000","discount_end_time":"1505232000","discount_price":"0.00","discount_type":"0","code_white_list":10001,"using_discount":False,"pay_price":"366.00","code":0}])
# data = {
#     "goods_ids":list_data
# }
# url = "http://order.imooc.com/pay/check"
# res = requests.post(url=url,data=data,cookies=cookies).text
# print res
# cookie11={'apsid':'E1NDcwMjg1MTdiN2NkMmI2Y2ZmOTgyYTZlZDRiMjUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMzY5OTE3OAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAyMzQ3MDk0OTNAcXEuY29tAAAAAAAAAAAAAAAAAAAAADBlYTE4MWQ3MzA0N2E2MzQzNDY0MWQ5ZjlhY2VhODE0MMV%2BWjDFflo%3DMz'}
# url1='http://www.imooc.com/apiw/addreplycomment'
# data1={
#     'uid':'3699178',
#     'content':'谁能带我走出迷雾，让我能够顺利地爬虫？',
#     'replyid':'277683',
#     'wap':'wap'
# }
# resa=requests.post(url=url1,data=data1,cookies=cookie11).text
# print resa

# url2='https://passport.isoftstone.com/?DomainUrl=http://ipsapro.isoftstone.com&ReturnUrl=%2fPortal'
# data2={
#     'emp_DomainName':'gnzhong',
#     'emp_Password':'abcdef.1234',
#     'RemeberMe':'true',
#     'DomainUrl':'',
#     'ReturnUrl':''
# }
# res2=requests.post(url=url2,data=data2,verify=False).text
# print res2

# url3='http://ipsapro.isoftstone.com/Portal'
# data3={
#
# }
# res3=requests.get(url=url3,data=data3,verify=False).text
# print res3
# Cookie: UserName=oZN7/I2ak40=; IsJV=True; .iPSA=F0A942C60B0A42EE6DE29F0266609E6DDAA9FAFF837D07DA69EDC94785CDBC5B628336AB2491923538B3CB918650E56D2EEE524B6B9EC2680DF9721D63AC7B3E00D49F88C428912BA4BBD8699061FC03; DomainName=gnzhong
Cookie={'.iPSA':'F0A942C60B0A42EE6DE29F0266609E6DDAA9FAFF837D07DA69EDC94785CDBC5B628336AB2491923538B3CB918650E56D2EEE524B6B9EC2680DF9721D63AC7B3E00D49F88C428912BA4BBD8699061FC03'}

#软通邮箱
url4='https://imail.isoftstone.com/zcs.php'
data4={
    'account':'gnzhong',
    'password':'abcdef.1234'
}
# res4=requests.post(url=url4,data=data4,verify=False).text
# print res4
url5='https://imail03.isoftstone.com:4430/service/soap/SendMsgRequest'
data5={"Header":{"context":{"session":{"id":"17737720","_content":"17737720"},"change":{"token":26606},"notify":[{"seq":3,"deleted":{"id":"-5880,5880"},"created":{"m":[{"s":1120,"d":1521953771000,"l":"5","cid":"-5881","f":"s","rev":26602,"id":"5881","e":[{"a":"1147721103@qq.com","d":"1147721103","t":"t"},{"a":"gnzhong@isoftstone.com","d":"Guangning","p":"Guangning Zhong","t":"f"}],"su":"test youxiang post","fr":"222222222222222222"}],"c":[{"id":"-5881","n":1,"f":"s","d":1521953771000,"su":"test youxiang post","e":[{"a":"gnzhong@isoftstone.com","d":"Guangning","p":"Guangning Zhong","t":"f"}]}],"cn":[{"id":"5882","l":"13","d":1521953771000,"rev":26604,"fileAsStr":"1147721103","_attrs":{"email":"1147721103@qq.com","firstName":"1147721103"}},{"id":"5883","l":"13","d":1521953771000,"rev":26605,"fileAsStr":"234709493","_attrs":{"email":"234709493@qq.com","firstName":"234709493"}}]},"modified":{"folder":[{"id":"13","uuid":"55b8192c-d369-4924-9aac-c3f66bfadb5f","n":5,"s":0,"i4ms":26605,"i4next":5884},{"id":"5","uuid":"1fcdc013-dd38-429f-92c7-c1552413335a","n":5,"s":1657066,"i4ms":26602,"i4next":5882},{"id":"6","uuid":"654ee524-9de4-45b8-81fc-169f5cfd31d7","n":0,"s":0,"i4ms":26606,"i4next":5881}],"mbx":[{"s":330406487}]}}],"_jsns":"urn:zimbra"}},"Body":{"SendMsgResponse":{"m":[{"id":"5881"}],"_jsns":"urn:zimbraMail"}},"_jsns":"urn:zimbraSoap"}

# res5=requests.post(url=url5,data=data5,cookies=Cookie,verify=False).text
# print res5
#https://imail03.isoftstone.com:4430/service/soap/SendMsgRequest
#{"Header":{"context":{"session":{"id":"17737720","_content":"17737720"},"change":{"token":26611},"notify":[{"seq":5,"deleted":{"id":"5884,-5884"},"created":{"m":[{"s":1094,"d":1521954907000,"l":"5","cid":"-5885","f":"s","rev":26609,"id":"5885","e":[{"a":"1147721103@qq.com","d":"1147721103","t":"t"},{"a":"gnzhong@isoftstone.com","d":"Guangning","p":"Guangning Zhong","t":"f"}],"su":"123123123ningning","fr":"123123123ningning"}],"c":[{"id":"-5885","n":1,"f":"s","d":1521954907000,"su":"123123123ningning","e":[{"a":"gnzhong@isoftstone.com","d":"Guangning","p":"Guangning Zhong","t":"f"}]}]},"modified":{"folder":[{"id":"5","uuid":"1fcdc013-dd38-429f-92c7-c1552413335a","n":6,"s":1658160,"i4ms":26609,"i4next":5886},{"id":"6","uuid":"654ee524-9de4-45b8-81fc-169f5cfd31d7","n":0,"s":0,"i4ms":26611,"i4next":5885}],"mbx":[{"s":330407581}]}}],"_jsns":"urn:zimbra"}},"Body":{"SendMsgResponse":{"m":[{"id":"5885"}],"_jsns":"urn:zimbraMail"}},"_jsns":"urn:zimbraSoap"}
#{"Header":{"context":{"session":{"id":"17737720","_content":"17737720"},"change":{"token":26613},"notify":[{"seq":6,"created":{"m":[{"s":1022,"d":1521955114000,"l":"5","cid":"-5886","f":"s","rev":26612,"id":"5886","e":[{"a":"1147721103@qq.com","d":"1147721103","t":"t"},{"a":"gnzhong@isoftstone.com","d":"Guangning","p":"Guangning Zhong","t":"f"}],"su":"456456456zhongzhong1","fr":"456456456zhongzhong2"}],"c":[{"id":"-5886","n":1,"f":"s","d":1521955114000,"su":"456456456zhongzhong1","e":[{"a":"gnzhong@isoftstone.com","d":"Guangning","p":"Guangning Zhong","t":"f"}]}]},"modified":{"folder":[{"id":"5","uuid":"1fcdc013-dd38-429f-92c7-c1552413335a","n":7,"s":1659182,"i4ms":26612,"i4next":5887}],"mbx":[{"s":330408603}]}}],"_jsns":"urn:zimbra"}},"Body":{"SendMsgResponse":{"m":[{"id":"5886"}],"_jsns":"urn:zimbraMail"}},"_jsns":"urn:zimbraSoap"}

url6='http://www.51zxw.net/remark.aspx?id=50192'
data6={
    'face':'1',
    'body':'is very good!thank you!!!!!!!!',
    'username':'ningguang',
    'clientDate':'Sun, 25 Mar 2018 05:47:08 GMT',
    'vcode':'49454951122892599126412303402421332456'
}
res6=requests.post(url=url6,data=data6).text
print res6
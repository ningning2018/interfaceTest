#coding:utf-8
import time
from suds.client import Client
url = 'http://www.webxml.com.cn/WebServices/IpAddressSearchWebService.asmx?wsdl'
client = Client(url)
print type(client.wsdl.services[0])
# print client.wsdl.services[0].ports[0].methods
def get_methods_name():
    method_list = []
    for i in client.wsdl.services[0].ports[0].methods:
        method_list.append(i)
    return method_list
# print client.service.getCountryCityByIp(theIpAddress='221.112.223.2')
print get_methods_name()
for i in get_methods_name():
    print i
    time.sleep(2)
    func = getattr(client.service,i)
    print func('112.212.121.2')
    # print client.service.i('221.112.223.2')
# print Client(url)
#coding:utf-8
import time
from suds.client import Client
url = 'http://www.webxml.com.cn/WebServices/IpAddressSearchWebService.asmx?wsdl'
client = Client(url)
print type(client.wsdl.services[0])
def get_methods_name():
    method_list = []
    for i in client.wsdl.services[0].ports[0].methods:
        method_list.append(i)
    return method_list
print get_methods_name()
for i in get_methods_name():
    print i
    time.sleep(2)
    func = getattr(client.service,i)
    print func('112.212.121.1')
print('#'*100)
#coding:utf-8
import time
from suds.client import Client
url = 'http://www.webxml.com.cn/WebServices/IpAddressSearchWebService.asmx?wsdl'
client = Client(url)
def get_methods_name():
    method_list = []
    for i in client.wsdl.services[0].ports[0].methods:
        method_list.append(i)
    return method_list
for i in get_methods_name():
    func = getattr(client.service,i)
    print func('221.232.121.2')
print client.service.getCountryCityByIp(theIpAddress='211.112.223.2')
#coding:utf-8
import time
from suds.client import Client
url = 'http://www.webxml.com.cn/WebServices/IpAddressSearchWebService.asmx?wsdl'
client = Client(url)
def get_methods_name():
    method_list = []
    for i in client.wsdl.services[0].ports[0].methods:
        method_list.append(i)
    return method_list
for i in get_methods_name():
    func = getattr(client.service,i)
    print func('221.222.211.2')
print client.service.getCountryCityByIp(theIpAddress='211.211.222.1')
# Activate new license with License server
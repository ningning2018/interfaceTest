#coding:utf-8
import MySQLdb.cursors
import json
# conn = MySQLdb.connect(
#             host = 'localhost',
#             port = '3306',
#             user = 'root',
#             passwd = '123456',
#             db = 'le_study',
#             charset = 'utf8'
#             )
# cur = conn.cursor()
# cur.execute("select * from web_user where Name='zhonggaungning'")
# print cur.fetchone()

class OperationMysql:
    def __init__(self):
        self.conn = MySQLdb.connect(
            host='localhost',
            port='33061',
            user='root',
            passwd='zwx1',
            db='le_study',
            charset='utf8',
            cursorclass = MySQLdb.cursors.DictCursor
        )
        self.cur = self.conn.cursor()
    #查询一条数据
    def search_one(self,sql):
        self.cur.execute(sql)
        result = self.cur.fetchone()
        result = json.dumps(result)
        return result

if __name__=='__main__':
    op_mysql = OperationMysql()
    res = op_mysql.search_one("select * from web_user where Name='zhonggaungning'")
    print(type(res))

#coding:utf-8
import json
class OperationJson:
    def __init__(self,file_path=None):
        if file_path == None:
            self.file_path = '../utilTwo_data_lx01/myOne.json'
        else:
            self.file_path = file_path
        self.data = self.read_data()
    def read_data(self):
        with open(self.file_path) as fp:
            data = json.load(fp)
            return data
    def get_data(self,id):
        return self.data[id]
    def write_value(self,data):
        with open('../utilTwo_data_lx01/cookie.json','w') as fp:
            fp.write(json.dumps(data))
    def write_json_data(self,data):
        with open('../utilTwo_data_lx01/writeOne.json','w') as fp:
            fp.write(json.dumps(data))
if __name__=='__main__':
    ope = OperationJson()
    print ope.data
    print ope.get_data('logs')
    print ope.write_value({'fffd':'ffdsf'})